from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from jose import JWTError, jwt
from datetime import datetime, timedelta
from pydantic import BaseModel
import bcrypt as _bcrypt
import threading
import time
from mt5_manager import mt5_manager


from database import SessionLocal, get_db
from models import Base, User, Trade, Signal
from schemas import UserCreate, MT5Credentials, Token
from auth import (
    
    oauth2_scheme,
    get_password_hash,
    verify_password,
    create_access_token,
    get_current_user,
)

from routes.auth_routes import router as auth_router

from routes.mt5_routes import router as mt5_router

from config import (
    engine,
    SECRET_KEY,
    ALGORITHM,
    ACCESS_TOKEN_EXPIRE_MINUTES,
)

app = FastAPI(title="GoldBot Platform")

app.include_router(auth_router)
app.include_router(mt5_router)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

SYMBOLS = ["XAUUSDm", "BTCUSDm", "ETHUSDm"]

DAILY_MAX_LOSS_PCT  = 0.02
DAILY_TARGET_PCT    = 0.03
RISK_PER_TRADE_PCT  = 0.01
MAX_OPEN_TRADES     = 3
MIN_SCORE           = 60
COOLDOWN_SECONDS    = 600
TRADE_START_HOUR    = 5
TRADE_END_HOUR      = 22
CLOSE_ALL_HOUR      = 21
MAX_SPREAD_POINTS   = 2000



Base.metadata.create_all(bind=engine)





def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()



def ema(prices, period):
    k = 2.0 / (period + 1)
    result = [prices[0]]
    for p in prices[1:]:
        result.append(p * k + result[-1] * (1 - k))
    return result

def calc_rsi(closes, period=14):
    deltas = [closes[i] - closes[i-1] for i in range(1, len(closes))]
    gains = [d if d > 0 else 0 for d in deltas]
    losses = [-d if d < 0 else 0 for d in deltas]
    avg_gain = sum(gains[-period:]) / period
    avg_loss = sum(losses[-period:]) / period
    if avg_loss == 0: return 100
    return 100 - (100 / (1 + avg_gain/avg_loss))

def calc_adx(highs, lows, closes, period=14):
    try:
        tr_list, pdm_list, ndm_list = [], [], []
        for i in range(1, len(closes)):
            tr = max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1]))
            pdm = max(highs[i]-highs[i-1], 0) if highs[i]-highs[i-1] > lows[i-1]-lows[i] else 0
            ndm = max(lows[i-1]-lows[i], 0) if lows[i-1]-lows[i] > highs[i]-highs[i-1] else 0
            tr_list.append(tr); pdm_list.append(pdm); ndm_list.append(ndm)
        atr = sum(tr_list[-period:]) / period
        if atr == 0: return 0
        pdi = (sum(pdm_list[-period:]) / period) / atr * 100
        ndi = (sum(ndm_list[-period:]) / period) / atr * 100
        return abs(pdi-ndi)/(pdi+ndi)*100 if (pdi+ndi) > 0 else 0
    except: return 0

def calc_atr(highs, lows, closes, period=14):
    try:
        tr_list = [max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1])) for i in range(1, len(closes))]
        return sum(tr_list[-period:]) / period
    except: return 0

def calc_macd(closes):
    e12 = ema(closes, 12)
    e26 = ema(closes, 26)
    macd_line = [a-b for a,b in zip(e12, e26)]
    signal_line = ema(macd_line, 9)
    hist = [m-s for m,s in zip(macd_line, signal_line)]
    return hist[-1], hist[-2]

def get_trend(symbol):
    rates = mt5_manager.copy_rates_from_pos(symbol, mt5_manager.TIMEFRAME_H4, 0, 250)
    if rates is None or len(rates) < 50:
        rates = mt5_manager.copy_rates_from_pos(symbol, mt5_manager.TIMEFRAME_H1, 0, 250)
    if rates is None or len(rates) < 50:
        return "BUY", 25
    closes = [r['close'] for r in rates]
    highs  = [r['high']  for r in rates]
    lows   = [r['low']   for r in rates]
    e200 = ema(closes, min(200, len(closes)-1))
    adx  = calc_adx(highs, lows, closes)
    trend = "BUY" if closes[-1] > e200[-1] else "SELL"
    return trend, adx

def calc_score(trend, adx, rsi, macd_h, macd_h_prev, closes, e50):
    score = 25
    if adx >= 30: score += 20
    elif adx >= 20: score += 12
    elif adx >= 15: score += 6
    if trend == "BUY" and 30 <= rsi <= 60: score += 20
    elif trend == "SELL" and 40 <= rsi <= 70: score += 20
    elif trend == "BUY" and rsi < 30: score += 15
    elif trend == "SELL" and rsi > 70: score += 15
    if trend == "BUY" and macd_h > 0 and macd_h > macd_h_prev: score += 15
    elif trend == "SELL" and macd_h < 0 and macd_h < macd_h_prev: score += 15
    elif trend == "BUY" and macd_h_prev < 0 < macd_h: score += 10
    elif trend == "SELL" and macd_h_prev > 0 > macd_h: score += 10
    score += 10
    if trend == "BUY" and closes[-1] > e50: score += 10
    elif trend == "SELL" and closes[-1] < e50: score += 10
    return score

def calculate_lot(balance, atr, symbol):
    try:
        risk_amount = balance * RISK_PER_TRADE_PCT
        info = mt5_manager.symbol_info(symbol)
        if info is None: return None
        tick_value = info.trade_tick_value
        tick_size  = info.trade_tick_size
        if atr == 0 or tick_value == 0 or tick_size == 0:
            return info.volume_min
        sl_ticks = (atr * 1.5) / tick_size
        lot = risk_amount / (sl_ticks * tick_value)
        lot = max(info.volume_min, min(info.volume_max, round(lot / info.volume_step) * info.volume_step))
        return round(lot, 2)
    except: return None

def close_position(pos):
    try:
        tick = mt5_manager.symbol_info_tick(pos.symbol)
        if tick is None: return False, 0
        price = tick.bid if pos.type == 0 else tick.ask
        request = {
            "action": mt5_manager.TRADE_ACTION_DEAL,
            "symbol": pos.symbol,
            "volume": pos.volume,
            "type": mt5_manager.ORDER_TYPE_SELL if pos.type == 0 else mt5_manager.ORDER_TYPE_BUY,
            "position": pos.ticket,
            "price": price,
            "deviation": 50,
            "magic": 888888,
            "comment": "GoldBot_Close",
            "type_time": mt5_manager.ORDER_TIME_GTC,
            "type_filling": mt5_manager.ORDER_FILLING_IOC,
        }
        result = mt5_manager.order_send(request)
        return result.retcode == mt5_manager.TRADE_RETCODE_DONE, pos.profit
    except: return False, 0

def update_trade_closed(user_id, symbol, profit, close_price):
    db = SessionLocal()
    try:
        t = db.query(Trade).filter(Trade.user_id==user_id, Trade.symbol==symbol, Trade.status=="open").first()
        if t:
            t.status = "closed"
            t.profit = float(profit)
            t.close_price = float(close_price)
            t.closed_at = datetime.utcnow()
            db.commit()
    finally:
        db.close()

active_bots = {}

def sync_closed_trades(user_id, balance):
    """Sync trades that were manually closed on MT5"""
    db = SessionLocal()
    try:
        open_trades = db.query(Trade).filter(
            Trade.user_id == user_id,
            Trade.status == "open"
        ).all()

        if not open_trades:
            db.close()
            return

        # Get current MT5 positions
        mt5_positions = mt5_manager.positions_get()
        mt5_tickets = set()
        if mt5_positions:
            for pos in mt5_positions:
                mt5_tickets.add(pos.symbol)

        for trade in open_trades:
            # If trade is in DB as open but not in MT5 positions
            sym_positions = mt5_manager.positions_get(symbol=trade.symbol)
            if not sym_positions:
                # Trade was closed externally
                tick = mt5_manager.symbol_info_tick(trade.symbol)
                close_price = tick.bid if trade.trade_type == "BUY" else tick.ask if tick else trade.open_price

                # Get deal history to find actual profit
                import MetaTrader5 as mt5
                from datetime import datetime, timedelta
                deals = mt5.history_deals_get(
                    datetime.now() - timedelta(hours=24),
                    datetime.now()
                )
                actual_profit = 0
                if deals:
                    for deal in deals:
                        if deal.symbol == trade.symbol and deal.entry == 1:  # entry=1 means close
                            actual_profit = deal.profit
                            close_price = deal.price
                            break

                trade.status = "closed"
                trade.close_price = float(close_price)
                trade.profit = float(actual_profit)
                trade.closed_at = datetime.utcnow()
                db.commit()
                print(f"[SYNC] Trade synced: {trade.symbol} P/L: ${actual_profit:.2f}")

                # Calculate platform fee (25%) - only above high water mark
                if actual_profit > 0:
                    current_bal = mt5_manager.account_info()
                    current_balance = current_bal.balance if current_bal else balance
                    fee, new_hwm = calculate_platform_fee(actual_profit, user_id, current_balance)
                    if fee > 0:
                        print(f"[FEE] Platform fee: ${fee:.2f} (25% of profit)")
                    else:
                        print(f"[FEE] No fee - still recovering losses")

    except Exception as e:
        print(f"[SYNC] Error: {e}")
    finally:
        db.close()

def get_high_water_mark(user_id):
    """Get highest balance ever achieved for this user"""
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if user and hasattr(user, 'high_water_mark') and user.high_water_mark:
            return float(user.high_water_mark)
        info = mt5_manager.account_info()
        return info.balance if info else 1000.0
    except:
        return 1000.0
    finally:
        db.close()

def calculate_platform_fee(profit, user_id, current_balance):
    """Calculate 25% fee only if above high water mark"""
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return 0, current_balance

        hwm = float(user.high_water_mark) if hasattr(user, 'high_water_mark') and user.high_water_mark else current_balance - profit

        if current_balance > hwm:
            # Only charge fee on profit above high water mark
            chargeable_profit = current_balance - hwm
            fee = min(profit * 0.25, chargeable_profit * 0.25)
            # Update high water mark
            if hasattr(user, 'high_water_mark'):
                user.high_water_mark = current_balance
                db.commit()
            print(f"[FEE] HWM: ${hwm:.2f} | Current: ${current_balance:.2f} | Fee: ${fee:.2f}")
            return fee, current_balance
        else:
            print(f"[FEE] Still in drawdown. HWM: ${hwm:.2f} | Current: ${current_balance:.2f} | No fee!")
            return 0, hwm
    except Exception as e:
        print(f"[FEE] Error: {e}")
        return 0, current_balance
    finally:
        db.close()

def run_user_bot(user_id, login, password, server):
    # Single MT5 initialization via manager
    if not mt5_manager.initialize(login=login, password=password, server=server):
        print(f"MT5 init failed for user {user_id}")
        return

    print(f"[THREAD] Bot thread started for user {user_id}")
    print(f"[THREAD] Professional MTF Strategy")
    last_trade_times = {}
    daily_start_balance = None
    last_date = None
    high_water_mark = None

    while active_bots.get(user_id, False):
        print(f"[LOOP] Iteration started")
        try:
            print(f"[MT5] Getting account info...")
            info = mt5_manager.account_info()
            if info is None:
                print(f"[MT5] Account info is None! Waiting...")
                time.sleep(10)
                continue

            balance = info.balance
            now = datetime.now()
            print(f"[MT5] Balance: ${balance:.2f} | Equity: ${info.equity:.2f}")

            if last_date != now.date():
                daily_start_balance = balance
                last_date = now.date()
                print(f"[DAY] New day! Balance: ${balance:.2f}")

            if daily_start_balance is None:
                daily_start_balance = balance

            # Initialize high water mark
            if high_water_mark is None:
                high_water_mark = balance
                print(f"[HWM] High Water Mark set: ${high_water_mark:.2f}")

            # Update high water mark if new high
            if balance > high_water_mark:
                high_water_mark = balance
                print(f"[HWM] New high! ${high_water_mark:.2f}")

            daily_pnl = (balance - daily_start_balance) / daily_start_balance
            print(f"[PNL] Daily P&L: {daily_pnl*100:.2f}%")

            # Daily target
            if daily_pnl >= DAILY_TARGET_PCT:
                print(f"Daily target {daily_pnl*100:.1f}%! Closing all...")
                positions = mt5_manager.positions_get()
                if positions:
                    for pos in positions:
                        if pos.magic == 888888:
                            done, profit = close_position(pos)
                            if done:
                                update_trade_closed(user_id, pos.symbol, profit, mt5_manager.symbol_info_tick(pos.symbol).bid)
                time.sleep(300)
                continue

            # Max loss
            if daily_pnl <= -DAILY_MAX_LOSS_PCT:
                print(f"Max loss {daily_pnl*100:.1f}%! Stopping...")
                positions = mt5_manager.positions_get()
                if positions:
                    for pos in positions:
                        if pos.magic == 888888:
                            close_position(pos)
                time.sleep(600)
                continue

            # End of day close
            if now.hour >= CLOSE_ALL_HOUR:
                positions = mt5_manager.positions_get()
                if positions:
                    for pos in positions:
                        if pos.magic == 888888:
                            tick = mt5_manager.symbol_info_tick(pos.symbol)
                            done, profit = close_position(pos)
                            if done and tick:
                                update_trade_closed(user_id, pos.symbol, profit, tick.bid if pos.type==0 else tick.ask)
                                print(f"EOD Close: {pos.symbol} P/L: ${pos.profit:.2f}")
                time.sleep(60)
                continue

            if not (TRADE_START_HOUR <= now.hour < TRADE_END_HOUR):
                print(f"[TIME] Outside hours {now.strftime('%H:%M')}. Waiting...")
                time.sleep(60)
                continue

            print(f"[TIME] Trading hours active: {now.strftime('%H:%M')}")

            # Manage open positions
            print(f"[POS] Checking open positions...")
            all_pos = mt5_manager.positions_get()
            bot_pos = [p for p in all_pos if p.magic == 888888] if all_pos else []
            print(f"[POS] Bot positions: {len(bot_pos)}")

            for pos in bot_pos:
                rates5 = mt5_manager.copy_rates_from_pos(pos.symbol, mt5_manager.TIMEFRAME_M5, 0, 100)
                if rates5 is None: continue
                closes = [r['close'] for r in rates5]
                macd_h, macd_h_prev = calc_macd(closes)
                rsi = calc_rsi(closes)

                should_close = False
                if pos.type == 0 and (macd_h < 0 and macd_h_prev > 0 or rsi > 72):
                    should_close = True
                elif pos.type == 1 and (macd_h > 0 and macd_h_prev < 0 or rsi < 28):
                    should_close = True

                if should_close and pos.profit > 0:
                    tick = mt5_manager.symbol_info_tick(pos.symbol)
                    done, profit = close_position(pos)
                    if done and tick:
                        update_trade_closed(user_id, pos.symbol, profit, tick.bid if pos.type==0 else tick.ask)
                        print(f"Close: {pos.symbol} P/L: ${pos.profit:.2f}")

            # Refresh
            all_pos = mt5_manager.positions_get()
            bot_pos = [p for p in all_pos if p.magic == 888888] if all_pos else []

            if len(bot_pos) >= MAX_OPEN_TRADES:
                time.sleep(30)
                continue

            # New entries
            print(f"[ENTRY] Looking for new entries...")
            for symbol in SYMBOLS:
                print(f"[SYMBOL] Checking {symbol}...")
                last_time = last_trade_times.get(symbol)
                if last_time:
                    elapsed = (datetime.now() - last_time).total_seconds()
                    if elapsed < COOLDOWN_SECONDS:
                        print(f"[COOLDOWN] {symbol} cooldown: {COOLDOWN_SECONDS-elapsed:.0f}s remaining")
                        continue

                sym_pos = [p for p in bot_pos if p.symbol == symbol]
                if sym_pos:
                    print(f"[SKIP] {symbol} already has open position")
                    continue

                # Spread check
                print(f"[SPREAD] Checking spread for {symbol}...")
                tick = mt5_manager.symbol_info_tick(symbol)
                sym_info = mt5_manager.symbol_info(symbol)
                if tick is None:
                    print(f"[SKIP] {symbol} tick is None!")
                    continue
                if sym_info is None:
                    print(f"[SKIP] {symbol} sym_info is None!")
                    continue
                spread = (tick.ask - tick.bid) / sym_info.point
                print(f"[SPREAD] {symbol} spread: {spread:.1f} points (max: {MAX_SPREAD_POINTS})")
                if spread > MAX_SPREAD_POINTS:
                    print(f"[SKIP] {symbol} spread too high!")
                    continue

                # Trend
                print(f"[DATA] Getting 4H trend for {symbol}...")
                trend, adx = get_trend(symbol)
                print(f"[TREND] {symbol} trend: {trend} | ADX: {adx:.1f}")

                # 5M data
                print(f"[DATA] Getting 5M candles for {symbol}...")
                rates5 = mt5_manager.copy_rates_from_pos(symbol, mt5_manager.TIMEFRAME_M5, 0, 100)
                if rates5 is None or len(rates5) < 50:
                    print(f"[DATA] {symbol} M5 data insufficient: {len(rates5) if rates5 else 'None'}")
                    continue
                print(f"[DATA] {symbol} M5 candles: {len(rates5)}")

                closes = [r['close'] for r in rates5]
                highs  = [r['high']  for r in rates5]
                lows   = [r['low']   for r in rates5]

                e9_list  = ema(closes, 9)
                e50_list = ema(closes, 50)
                rsi      = calc_rsi(closes)
                atr      = calc_atr(highs, lows, closes)
                macd_h, macd_h_prev = calc_macd(closes)

                score = calc_score(trend, adx, rsi, macd_h, macd_h_prev, closes, e50_list[-1])

                print(f"[{now.strftime('%H:%M:%S')}] {symbol} | Trend:{trend} | ADX:{adx:.1f} | RSI:{rsi:.1f} | MACD:{macd_h:.4f} | Score:{score}")

                db = SessionLocal()
                sig = Signal(symbol=symbol, signal_type=trend if score>=MIN_SCORE else "WAIT",
                             score=score, ema_fast=e9_list[-1], ema_slow=e50_list[-1],
                             macd=macd_h, rsi=rsi, adx=adx, price=closes[-1])
                db.add(sig); db.commit(); db.close()

                if score < MIN_SCORE:
                    time.sleep(1)
                    continue

                lot = calculate_lot(balance, atr, symbol)
                if lot is None: continue

                entry = tick.ask if trend == "BUY" else tick.bid
                point = sym_info.point
                sl = entry - atr*1.5 if trend == "BUY" else entry + atr*1.5
                tp = entry + atr*2.5 if trend == "BUY" else entry - atr*2.5

                request = {
                    "action": mt5_manager.TRADE_ACTION_DEAL,
                    "symbol": symbol,
                    "volume": lot,
                    "type": mt5_manager.ORDER_TYPE_BUY if trend=="BUY" else mt5_manager.ORDER_TYPE_SELL,
                    "price": entry,
                    "sl": sl,
                    "tp": tp,
                    "deviation": 50,
                    "magic": 888888,
                    "comment": f"GoldBot_{score}",
                    "type_time": mt5_manager.ORDER_TIME_GTC,
                    "type_filling": mt5_manager.ORDER_FILLING_IOC,
                }
                result = mt5_manager.order_send(request)
                if result.retcode == mt5_manager.TRADE_RETCODE_DONE:
                    last_trade_times[symbol] = datetime.now()
                    print(f"TRADE: {symbol} {trend} @ {entry:.2f} Score:{score} Lot:{lot}")
                    db = SessionLocal()
                    trade = Trade(user_id=user_id, symbol=symbol, trade_type=trend,
                                  lot=lot, open_price=entry, score=score, status="open")
                    db.add(trade); db.commit(); db.close()
                else:
                    print(f"Failed {symbol}: {result.retcode} - {result.comment}")
                time.sleep(1)

            # Sync manually closed trades
            sync_closed_trades(user_id, balance)

            print(f"[SLEEP] Sleeping 60 seconds...")
            time.sleep(60)

        except Exception as e:
            import traceback
            print(f"[ERROR] Exception in bot loop!")
            traceback.print_exc()
            print(f"[ERROR] {e}")
            time.sleep(10)

    active_bots.pop(user_id, None)

    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if user:
            user.bot_active = False
            db.commit()
    finally:
        db.close()

    print(f"Bot stopped for user {user_id}")

# API Routes
    

@app.get("/me")
def get_me(current_user: User = Depends(get_current_user)):
    if current_user.mt5_login:
        mt5_manager.initialize(
            login=current_user.mt5_login,
            password=current_user.mt5_password,
            server=current_user.mt5_server,
        )

    info = mt5_manager.account_info()
    print("ACCOUNT INFO =", info)
    print("BOT ACTIVE =", current_user.bot_active)

    return {
        "username": current_user.username,
        "email": current_user.email,
        "mt5_connected": current_user.mt5_login is not None,
        "mt5_login": current_user.mt5_login,
        "mt5_server": current_user.mt5_server,
        "bot_active": current_user.bot_active,
        "balance": info.balance if info else 0,
        "profit": info.profit if info else 0,
        "equity": info.equity if info else 0,
    }

    

@app.post("/bot/start")
def start_bot(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.mt5_login:
        raise HTTPException(status_code=400, detail="Connect MT5 first")
    print("ACTIVE_BOTS =", active_bots)
print("CURRENT USER =", current_user.id)
    if active_bots.get(current_user.id):
        return {"message": "Bot already running"}
    active_bots[current_user.id] = True
    current_user.bot_active = True
    db.commit()
    thread = threading.Thread(
        target=run_user_bot,
        args=(current_user.id, current_user.mt5_login, current_user.mt5_password, current_user.mt5_server),
        daemon=True
    )
    thread.start()
    return {"message": "Bot started!"}

@app.post("/bot/stop")
def stop_bot(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    active_bots[current_user.id] = False

    db_user = db.query(User).filter(User.id == current_user.id).first()

    if db_user:
        db_user.bot_active = False
        db.commit()
        db.refresh(db_user)

    print(f"[BOT] Stopped user {current_user.id}")

    return {"message": "Bot stopped"}

@app.get("/signals")
def get_signals(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(Signal).order_by(Signal.created_at.desc()).limit(50).all()

@app.get("/trades")
def get_trades(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(Trade).filter(Trade.user_id == current_user.id).order_by(Trade.opened_at.desc()).all()

@app.get("/")
def root():
    return {"message": "GoldBot Professional MTF API"}